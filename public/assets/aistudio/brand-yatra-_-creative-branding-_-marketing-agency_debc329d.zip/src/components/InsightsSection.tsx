import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, ArrowUpRight, Clock } from 'lucide-react';
import { ARTICLES_LIST, ArticleItem } from '../data/agencyData';

interface InsightsSectionProps {
  onSelectArticle: (article: ArticleItem) => void;
}

export const InsightsSection: React.FC<InsightsSectionProps> = ({ onSelectArticle }) => {
  const [carouselIndex, setCarouselIndex] = useState(0);

  const handlePrev = () => {
    setCarouselIndex((prev) => (prev === 0 ? ARTICLES_LIST.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCarouselIndex((prev) => (prev === ARTICLES_LIST.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="insights" className="py-24 bg-[#191919] text-[#FFF8F3] border-t border-[#333333] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header with Desktop Carousel Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div>
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-2 h-2 rounded-full bg-[#F74300]" />
              <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#FFE4D6]">
                AGENCY INTELLIGENCE
              </span>
            </div>
            <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl text-[#FFF8F3] uppercase tracking-tight">
              MORE GROWTH. <span className="text-[#F74300]">MORE INSIGHT.</span>
            </h2>
          </div>

          {/* Carousel Arrows */}
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrev}
              className="w-11 h-11 rounded-full bg-[#222222] border border-[#333333] hover:border-[#F74300] hover:text-[#F74300] text-[#FFF8F3] flex items-center justify-center transition-all duration-200 cursor-pointer active:scale-95"
              aria-label="Previous article"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNext}
              className="w-11 h-11 rounded-full bg-[#222222] border border-[#333333] hover:border-[#F74300] hover:text-[#F74300] text-[#FFF8F3] flex items-center justify-center transition-all duration-200 cursor-pointer active:scale-95"
              aria-label="Next article"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Editorial Article Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {ARTICLES_LIST.map((article) => (
            <div
              key={article.id}
              className="bg-[#222222] border border-[#333333] hover:border-[#F74300]/60 rounded-2xl p-6 transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1"
            >
              <div>
                {/* Meta info */}
                <div className="flex items-center justify-between text-[11px] text-[#B8B8C2] mb-4 pb-3 border-b border-[#333333]">
                  <span className="text-[#F74300] font-bold uppercase tracking-wider font-['Plus_Jakarta_Sans',sans-serif]">
                    {article.category}
                  </span>
                  <span className="flex items-center gap-1 font-mono text-[10px]">
                    <Clock className="w-3 h-3 text-[#B8B8C2]" />
                    {article.readTime}
                  </span>
                </div>

                {/* Title with Marcellus */}
                <h3 className="font-['Marcellus',serif] text-lg sm:text-xl text-[#FFF8F3] mb-3 leading-snug group-hover:text-[#F74300] transition-colors line-clamp-2">
                  {article.title}
                </h3>

                {/* Excerpt */}
                <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs text-[#B8B8C2] leading-relaxed line-clamp-3 mb-6">
                  {article.summary}
                </p>
              </div>

              {/* Action Button */}
              <div className="pt-4 border-t border-[#333333]">
                <button
                  onClick={() => onSelectArticle(article)}
                  className="w-full flex items-center justify-between text-xs font-bold uppercase tracking-wider text-[#FFF8F3] group-hover:text-[#F74300] transition-colors cursor-pointer py-1 font-['Plus_Jakarta_Sans',sans-serif]"
                >
                  <span>READ ARTICLE</span>
                  <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
