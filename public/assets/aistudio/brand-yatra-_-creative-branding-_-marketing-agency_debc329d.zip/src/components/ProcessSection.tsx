import React from 'react';
import { ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { PROCESS_STEPS } from '../data/agencyData';
import { BtnShape } from './BtnShape';

interface ProcessSectionProps {
  onOpenConsultation: () => void;
}

export const ProcessSection: React.FC<ProcessSectionProps> = ({ onOpenConsultation }) => {
  return (
    <section id="process" className="py-24 bg-[#FFF8F3] text-[#191919] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Number Badge & Eyebrow */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-7 h-7 rounded-full bg-[#191919] text-[#FFF8F3] text-xs font-bold flex items-center justify-center font-mono">
            3
          </div>
          <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#191919]/70">
            OUR PROCESS &amp; METHODOLOGY
          </span>
        </div>

        {/* Header Grid with 3D Geometric Emblem */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          <div className="lg:col-span-8">
            <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl text-[#191919] tracking-tight uppercase leading-[1.15] mb-4">
              OUR PROCESS
            </h2>
            <p className="font-['Plus_Jakarta_Sans',sans-serif] text-base text-[#191919]/80 max-w-xl leading-relaxed">
              A clear, collaborative approach to building enduring brand authority and delivering
              measurable, compounding commercial growth across every digital touchpoint.
            </p>
          </div>

          {/* Reference-matched 3D isometric geometric Brand Yatra emblem */}
          <div className="lg:col-span-4 flex justify-start lg:justify-end">
            <div className="w-36 h-36 sm:w-44 sm:h-44 relative flex items-center justify-center">
              <svg
                viewBox="0 0 200 200"
                className="w-full h-full drop-shadow-xl"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* 3D Isometric Cube / Prism Facets with Brand Yatra Orange */}
                <polygon
                  points="100,20 180,65 100,110 20,65"
                  fill="#F74300"
                  className="transition-all hover:brightness-110"
                />
                <polygon
                  points="20,65 100,110 100,190 20,145"
                  fill="#191919"
                />
                <polygon
                  points="100,110 180,65 180,145 100,190"
                  fill="#FFE4D6"
                />
                {/* Inner decorative facet line */}
                <line x1="100" y1="20" x2="100" y2="110" stroke="#FFFFFF" strokeWidth="2" strokeOpacity="0.5" />
                <line x1="20" y1="65" x2="100" y2="110" stroke="#FFFFFF" strokeWidth="2" strokeOpacity="0.5" />
                <line x1="180" y1="65" x2="100" y2="110" stroke="#FFFFFF" strokeWidth="2" strokeOpacity="0.5" />
              </svg>
            </div>
          </div>
        </div>

        {/* Four Compact Process Blocks in a 2-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10 mb-16">
          {PROCESS_STEPS.map((step) => (
            <div
              key={step.step}
              className="border-t-2 border-[#191919]/15 pt-6 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-['Marcellus',serif] text-xs tracking-widest text-[#F74300] uppercase">
                    STEP {step.step}
                  </span>
                  <span className="text-[11px] font-mono text-[#191919]/60 uppercase">
                    {step.subtitle}
                  </span>
                </div>

                <h3 className="font-['Marcellus',serif] text-2xl text-[#191919] mb-3">
                  {step.title}
                </h3>

                <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm text-[#191919]/80 leading-relaxed mb-4">
                  {step.description}
                </p>
              </div>

              <div className="pt-3 border-t border-[#191919]/10 flex items-center gap-2 text-[11px] text-[#191919]/90 font-medium font-['Plus_Jakarta_Sans',sans-serif]">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#F74300] flex-shrink-0" />
                <span>Deliverables: {step.keyDeliverables}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner: Dark Charcoal Surface with srv_shape.webp & Orange CTA */}
        <div className="group relative bg-[#191919] text-[#FFF8F3] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl border border-[#333333] overflow-hidden">
          {/* Horizontal Shape Overlay from /public/assets/srv_shape.webp */}
          <img
            src="/assets/srv_shape.webp"
            alt=""
            aria-hidden="true"
            className="absolute inset-0 w-full h-full object-fill pointer-events-none z-0 opacity-25 group-hover:opacity-60 transition-opacity duration-300"
          />

          <div className="relative z-10 flex items-center gap-4">
            <div className="w-8 h-8 rounded-full bg-[#F74300] text-white flex items-center justify-center font-bold text-xs flex-shrink-0 font-mono">
              4
            </div>
            <div>
              <div className="font-['Marcellus',serif] text-base sm:text-lg text-white uppercase tracking-wider mb-1">
                NEED A CUSTOM SOLUTION?
              </div>
              <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs text-[#B8B8C2] max-w-xl leading-relaxed">
                No generic packages. We build the right channel mix around your search
                demand, competitive landscape, goals, budget, and conversion potential.
              </p>
            </div>
          </div>

          <div className="relative z-10 flex-shrink-0">
            <button
              onClick={onOpenConsultation}
              className="group/btn relative inline-flex items-center justify-center gap-2.5 text-white font-['Plus_Jakarta_Sans',sans-serif] text-xs font-bold uppercase tracking-wider px-7 py-3.5 transition-all duration-200 active:scale-95 filter drop-shadow-[0_4px_12px_rgba(247,67,0,0.3)] cursor-pointer"
            >
              <BtnShape fill="#F74300" />
              <span className="relative z-10">BOOK A STRATEGY CALL</span>
              <ArrowUpRight className="relative z-10 w-4 h-4 stroke-[2.5]" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
