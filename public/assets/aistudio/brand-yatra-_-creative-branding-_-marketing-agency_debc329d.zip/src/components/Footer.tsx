import React from 'react';
import { ArrowUpRight, ArrowUp, MessageCircle, Phone, Mail, MapPin } from 'lucide-react';
import { AGENCY_INFO, SERVICES_LIST } from '../data/agencyData';

interface FooterProps {
  onOpenConsultation: () => void;
  onOpenLegal: (type: 'terms' | 'privacy') => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenConsultation, onOpenLegal }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#141414] text-[#FFF8F3] border-t border-[#333333] pt-20 pb-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Giant Circular "PING US" Signature Action Area */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12 pb-20 border-b border-[#333333]">
          <div className="max-w-xl text-center lg:text-left">
            <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl lg:text-5xl uppercase tracking-tight text-[#FFF8F3] mb-4">
              READY TO SCALE YOUR <span className="text-[#F74300]">BRAND IMPACT?</span>
            </h2>
            <p className="font-['Plus_Jakarta_Sans',sans-serif] text-sm text-[#B8B8C2] leading-relaxed">
              Connect with our partners today to explore brand positioning, search dominance,
              and performance marketing calibrated for measurable revenue.
            </p>
          </div>

          {/* Reference-matched giant circular "PING US" button */}
          <div className="flex-shrink-0">
            <button
              onClick={onOpenConsultation}
              className="group w-44 h-44 sm:w-52 sm:h-52 rounded-full bg-[#F74300] hover:bg-[#FF5514] text-white flex flex-col items-center justify-center p-6 shadow-2xl shadow-[#F74300]/30 hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer"
            >
              <div className="flex items-center gap-1 mb-1">
                <ArrowUpRight className="w-6 h-6 stroke-[3] group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                <ArrowUpRight className="w-6 h-6 stroke-[3] group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform delay-75" />
              </div>
              <span className="font-['Marcellus',serif] text-2xl sm:text-3xl tracking-wider uppercase leading-none">
                PING US
              </span>
              <span className="text-[10px] uppercase tracking-widest text-white/80 font-mono mt-1 font-['Plus_Jakarta_Sans',sans-serif]">
                START NOW
              </span>
            </button>
          </div>
        </div>

        {/* Footer Navigation Columns */}
        <div className="py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Col 1: Brand Wordmark & Summary */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-lg bg-[#222222] border border-[#333333] flex items-center justify-center p-1.5">
                <svg viewBox="0 0 40 40" fill="none" className="w-full h-full">
                  <path d="M8 32L20 8L32 32H24L20 18L16 32H8Z" fill="#F74300" />
                  <circle cx="20" cy="27" r="3" fill="#FFE4D6" />
                </svg>
              </div>
              <span className="font-['Marcellus',serif] text-xl tracking-wider text-[#FFF8F3] uppercase">
                BRAND YATRA
              </span>
            </div>
            <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs text-[#B8B8C2] leading-relaxed max-w-sm mb-6">
              Brand Yatra is an elite creative branding and digital marketing agency.
              We build distinctive brands and run high-efficiency customer acquisition engines.
            </p>
            <div className="text-xs text-[#B8B8C2] space-y-2 font-['Plus_Jakarta_Sans',sans-serif]">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#F74300]" />
                <span>
                  {AGENCY_INFO.address.line1}, {AGENCY_INFO.address.city}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#F74300]" />
                <a href={`mailto:${AGENCY_INFO.email}`} className="hover:text-[#F74300] transition-colors">
                  {AGENCY_INFO.email}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#F74300]" />
                <a href="tel:+918041228890" className="hover:text-[#F74300] transition-colors">
                  {AGENCY_INFO.phone}
                </a>
              </div>
            </div>
          </div>

          {/* Col 2: Core Services */}
          <div>
            <h4 className="font-['Marcellus',serif] text-sm uppercase tracking-widest text-[#FFF8F3] mb-4">
              Core Services
            </h4>
            <ul className="space-y-2.5 text-xs text-[#B8B8C2] font-['Plus_Jakarta_Sans',sans-serif]">
              {SERVICES_LIST.slice(0, 5).map((s) => (
                <li key={s.id}>
                  <a href="#services" className="hover:text-[#F74300] transition-colors">
                    {s.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Useful Links */}
          <div>
            <h4 className="font-['Marcellus',serif] text-sm uppercase tracking-widest text-[#FFF8F3] mb-4">
              Navigation
            </h4>
            <ul className="space-y-2.5 text-xs text-[#B8B8C2] font-['Plus_Jakarta_Sans',sans-serif]">
              <li>
                <a href="#services" className="hover:text-[#F74300] transition-colors">
                  Services
                </a>
              </li>
              <li>
                <a href="#strategy" className="hover:text-[#F74300] transition-colors">
                  Growth Strategy
                </a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-[#F74300] transition-colors">
                  Case Studies
                </a>
              </li>
              <li>
                <a href="#process" className="hover:text-[#F74300] transition-colors">
                  Our Process
                </a>
              </li>
              <li>
                <a href="#capabilities" className="hover:text-[#F74300] transition-colors">
                  Capabilities
                </a>
              </li>
              <li>
                <a href="#insights" className="hover:text-[#F74300] transition-colors">
                  Insights &amp; Articles
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Social Media */}
          <div>
            <h4 className="font-['Marcellus',serif] text-sm uppercase tracking-widest text-[#FFF8F3] mb-4">
              Social Media
            </h4>
            <ul className="space-y-2.5 text-xs text-[#B8B8C2] font-['Plus_Jakarta_Sans',sans-serif]">
              {AGENCY_INFO.socials.map((soc) => (
                <li key={soc.name}>
                  <a
                    href={soc.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-[#F74300] transition-colors flex items-center gap-1.5"
                  >
                    <span>{soc.name}</span>
                    <ArrowUpRight className="w-3 h-3 text-[#B8B8C2]" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Legal */}
        <div className="pt-8 border-t border-[#333333] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#B8B8C2] font-['Plus_Jakarta_Sans',sans-serif]">
          <div className="flex items-center gap-2">
            <span>Copyright &copy; {new Date().getFullYear()} Brand Yatra. All rights reserved.</span>
          </div>

          <div className="flex items-center gap-6">
            <button
              onClick={() => onOpenLegal('terms')}
              className="hover:text-[#FFF8F3] transition-colors cursor-pointer"
            >
              Terms &amp; Conditions
            </button>
            <button
              onClick={() => onOpenLegal('privacy')}
              className="hover:text-[#FFF8F3] transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
          </div>
        </div>
      </div>

      {/* Floating Action Buttons: WhatsApp & Back to Top */}
      <div className="fixed bottom-6 left-6 z-40">
        <a
          href="https://wa.me/918041228890?text=Hello%20Brand%20Yatra,%20I%20would%20like%20to%20discuss%20a%20project."
          target="_blank"
          rel="noopener noreferrer"
          className="w-12 h-12 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-xl shadow-black/40 hover:scale-110 active:scale-95 transition-all cursor-pointer"
          aria-label="Chat on WhatsApp"
          title="Chat with Brand Yatra"
        >
          <MessageCircle className="w-6 h-6" />
        </a>
      </div>

      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={scrollToTop}
          className="w-12 h-12 rounded-full bg-[#F74300] hover:bg-[#FF5514] text-white flex items-center justify-center shadow-xl shadow-[#F74300]/30 hover:scale-110 active:scale-95 transition-all cursor-pointer"
          aria-label="Scroll to top"
          title="Back to Top"
        >
          <ArrowUp className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>
    </footer>
  );
};
