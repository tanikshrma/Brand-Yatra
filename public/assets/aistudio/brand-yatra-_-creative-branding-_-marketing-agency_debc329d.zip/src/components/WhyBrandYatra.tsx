import React from 'react';
import { ArrowUpRight, Zap, Target, Layers, BarChart3 } from 'lucide-react';
import { BtnShape } from './BtnShape';

interface WhyBrandYatraProps {
  onOpenConsultation: () => void;
}

export const WhyBrandYatra: React.FC<WhyBrandYatraProps> = ({ onOpenConsultation }) => {
  const pillars = [
    {
      icon: <Zap className="w-4 h-4 text-[#F74300]" />,
      title: 'Aesthetic Conviction',
      desc: 'Distinct visual identity and premium editorial design that sets your brand apart from generic digital templates.',
    },
    {
      icon: <Target className="w-4 h-4 text-[#F74300]" />,
      title: 'Intent-First Acquisition',
      desc: 'Laser-focused Google Ads and SEO funnels capturing buyers at the exact moment of commercial consideration.',
    },
    {
      icon: <Layers className="w-4 h-4 text-[#F74300]" />,
      title: 'Connected Execution',
      desc: 'Zero siloed handoffs. Brand strategists, media buyers, and UI engineers work in lockstep under one roof.',
    },
    {
      icon: <BarChart3 className="w-4 h-4 text-[#F74300]" />,
      title: 'Compounding Revenue',
      desc: 'Data pipelines calibrated around true contribution margin, ROAS, and customer lifetime value.',
    },
  ];

  return (
    <section className="py-20 bg-[#141414] border-y border-[#333333] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Asymmetric Typography & Call to Action */}
          <div className="lg:col-span-6">
            <div className="inline-flex items-center gap-2 mb-4">
              <span className="w-2 h-2 rounded-full bg-[#F74300]" />
              <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#FFE4D6]">
                WHY BRAND YATRA
              </span>
            </div>

            <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl text-[#FFF8F3] uppercase tracking-tight leading-tight mb-6">
              BUILT AROUND <span className="text-[#F74300]">YOUR GROWTH</span>
            </h2>

            <p className="font-['Plus_Jakarta_Sans',sans-serif] text-sm sm:text-base text-[#B8B8C2] leading-relaxed mb-8 max-w-lg">
              Creative thinking, clear strategy, and connected execution help every part
              of your brand work together. We eliminate agency friction to deliver tangible
              commercial outcomes.
            </p>

            <div>
              <button
                onClick={onOpenConsultation}
                className="group relative inline-flex items-center justify-center gap-2.5 text-white font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm font-bold uppercase tracking-wider px-8 py-4 transition-all duration-200 filter drop-shadow-[0_8px_16px_rgba(247,67,0,0.25)] hover:scale-105 active:scale-95 cursor-pointer"
              >
                <BtnShape fill="#F74300" />
                <span className="relative z-10">LET'S BUILD SOMETHING BETTER</span>
                <ArrowUpRight className="relative z-10 w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          </div>

          {/* Right Column: Supporting Pillar Blocks with car_shape.webp */}
          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {pillars.map((item, idx) => (
              <div
                key={idx}
                className="group relative bg-[#191919] border border-[#333333] hover:border-[#F74300]/60 rounded-xl p-5 transition-all duration-200 overflow-hidden"
              >
                {/* Portrait Card Shape Overlay */}
                <img
                  src="/assets/car_shape.webp"
                  alt=""
                  aria-hidden="true"
                  className="absolute inset-0 w-full h-full object-fill pointer-events-none z-0 opacity-20 group-hover:opacity-60 transition-opacity duration-300"
                />

                <div className="relative z-10">
                  <div className="w-9 h-9 rounded-lg bg-[#222222] border border-[#333333] flex items-center justify-center mb-3.5">
                    {item.icon}
                  </div>
                  <h3 className="font-['Marcellus',serif] text-base text-[#FFF8F3] mb-2 uppercase tracking-wide">
                    {item.title}
                  </h3>
                  <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs text-[#B8B8C2] leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
