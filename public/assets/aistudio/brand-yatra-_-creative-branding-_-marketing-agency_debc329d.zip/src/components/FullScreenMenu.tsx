import React, { useEffect, useRef } from 'react';
import { X, ArrowUpRight, ArrowUp } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData';

interface FullScreenMenuProps {
  isOpen: boolean;
  onClose: () => void;
  triggerButtonRef?: React.RefObject<HTMLButtonElement | null>;
}

export const FullScreenMenu: React.FC<FullScreenMenuProps> = ({
  isOpen,
  onClose,
  triggerButtonRef,
}) => {
  const overlayRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  const menuLinks = [
    { label: 'Core Service', href: '#services', number: '01' },
    { label: 'What we do', href: '#strategy', number: '02' },
    { label: 'Features', href: '#capabilities', number: '03' },
    { label: 'Portfolio', href: '#portfolio', number: '04' },
    { label: 'Other Services', href: '#process', number: '05' },
    { label: 'Contact', href: '#contact', number: '06' },
  ];

  useEffect(() => {
    if (isOpen) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';

      const timer = setTimeout(() => {
        closeButtonRef.current?.focus();
      }, 100);

      return () => {
        document.body.style.overflow = originalOverflow;
        clearTimeout(timer);
      };
    } else {
      document.body.style.overflow = '';
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
        triggerButtonRef?.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, triggerButtonRef]);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    onClose();

    const targetElement = document.querySelector(href);
    if (targetElement) {
      setTimeout(() => {
        targetElement.scrollIntoView({ behavior: 'smooth' });
      }, 350);
    } else {
      window.location.hash = href;
    }
  };

  const handleBackToTop = () => {
    onClose();
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 300);
  };

  return (
    <div
      ref={overlayRef}
      role="dialog"
      aria-modal="true"
      aria-label="Main Navigation Menu"
      className={`fixed inset-0 z-50 transition-all duration-700 ease-cinema ${
        isOpen
          ? 'opacity-100 pointer-events-auto visible'
          : 'opacity-0 pointer-events-none invisible'
      }`}
    >
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-500"
        onClick={onClose}
      />

      <div className="relative w-full h-full flex flex-col lg:flex-row overflow-y-auto lg:overflow-hidden select-none">
        
        {/* LEFT PANEL: 67% width on desktop, background #191919 (dark charcoal) */}
        <div
          className={`w-full lg:w-[67%] bg-[#191919] text-[#FFF8F3] min-h-screen lg:min-h-full flex flex-col justify-between p-8 sm:p-14 lg:p-20 xl:p-24 transition-transform duration-700 ease-cinema relative z-10 ${
            isOpen ? 'translate-y-0 lg:translate-x-0' : '-translate-y-8 lg:-translate-x-12'
          }`}
        >
          <div
            className={`transition-all duration-500 delay-100 ${
              isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
            }`}
          >
            <div className="inline-flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#F74300]" />
              <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#B8B8C2]">
                NAVIGATION MENU
              </span>
            </div>
          </div>

          <nav className="my-auto py-10 lg:py-0">
            <ul className="flex flex-col space-y-4 sm:space-y-6 lg:space-y-7 xl:space-y-8">
              {menuLinks.map((link, idx) => {
                const delayMs = isOpen ? idx * 70 + 150 : 0;

                return (
                  <li
                    key={link.label}
                    style={{
                      transitionDelay: `${delayMs}ms`,
                    }}
                    className={`transform transition-all duration-700 ease-cinema ${
                      isOpen
                        ? 'opacity-100 translate-y-0'
                        : 'opacity-0 translate-y-10'
                    }`}
                  >
                    <a
                      href={link.href}
                      onClick={(e) => handleNavClick(e, link.href)}
                      className="group inline-flex items-baseline gap-4 sm:gap-6 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F74300] rounded-lg"
                    >
                      <span className="font-mono text-xs sm:text-sm text-[#B8B8C2]/40 group-hover:text-[#F74300] transition-colors duration-300">
                        /{link.number}
                      </span>

                      {/* Marcellus Font for prominent large menu links */}
                      <span className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl lg:text-[54px] xl:text-[62px] tracking-tight leading-[1.1] text-[#FFF8F3] group-hover:text-[#F74300] group-hover:translate-x-2 transition-all duration-300 ease-out">
                        {link.label}
                      </span>

                      <ArrowUpRight className="w-6 h-6 sm:w-8 sm:h-8 text-[#F74300] opacity-0 -translate-x-3 translate-y-2 group-hover:opacity-100 group-hover:translate-x-0 group-hover:translate-y-0 transition-all duration-300 ease-out hidden sm:inline-block" />
                    </a>
                  </li>
                );
              })}
            </ul>
          </nav>

          <div
            className={`flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-[#B8B8C2]/60 pt-6 border-t border-white/5 transition-all duration-700 delay-500 ${
              isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <span className="font-['Marcellus',serif] tracking-wider uppercase text-[#FFF8F3]/70">
              Brand Yatra &copy; {new Date().getFullYear()} · Creative Agency
            </span>
            <span className="font-mono text-[11px] text-[#B8B8C2]/40">
              [PRESS ESC TO CLOSE]
            </span>
          </div>
        </div>

        {/* RIGHT PANEL: 33% width on desktop, background #222222 */}
        <div
          className={`w-full lg:w-[33%] bg-[#222222] text-[#FFF8F3] border-t lg:border-t-0 lg:border-l border-white/10 p-8 sm:p-12 lg:p-14 xl:p-16 flex flex-col justify-between relative transition-transform duration-700 ease-cinema ${
            isOpen ? 'translate-y-0 lg:translate-x-0' : 'translate-y-8 lg:translate-x-12'
          }`}
        >
          <div className="flex justify-end mb-8 lg:mb-12">
            <button
              ref={closeButtonRef}
              onClick={onClose}
              aria-label="Close navigation menu"
              className="w-12 h-12 rounded-full bg-white/5 hover:bg-[#F74300] text-[#FFF8F3] hover:text-white border border-white/10 hover:border-[#F74300] flex items-center justify-center transition-all duration-300 cursor-pointer active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F74300]"
            >
              <X className="w-6 h-6 stroke-[1.8]" />
            </button>
          </div>

          <div className="space-y-10 lg:space-y-12 my-auto">
            {/* GROUP 1: Brief Us */}
            <div
              className={`transition-all duration-700 delay-200 ${
                isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <h3 className="font-['Marcellus',serif] text-2xl sm:text-[28px] lg:text-[32px] text-[#FFF8F3] tracking-tight uppercase mb-3">
                Brief Us
              </h3>
              <a
                href={`mailto:${AGENCY_INFO.email}`}
                className="inline-block text-base sm:text-lg text-[#F74300] hover:text-[#FFE4D6] font-medium tracking-wide mb-2 transition-colors"
              >
                {AGENCY_INFO.email}
              </a>
              <p className="text-xs sm:text-sm text-[#B8B8C2] leading-relaxed max-w-xs font-['Plus_Jakarta_Sans',sans-serif]">
                We'd love to hear about your brand vision, creative strategy, and digital marketing requirements.
              </p>
            </div>

            {/* GROUP 2: Our Office */}
            <div
              className={`transition-all duration-700 delay-300 ${
                isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <h3 className="font-['Marcellus',serif] text-2xl sm:text-[28px] lg:text-[32px] text-[#FFF8F3] tracking-tight uppercase mb-3">
                Our Office
              </h3>
              <div className="text-xs sm:text-sm text-[#B8B8C2] leading-relaxed max-w-xs space-y-1 font-['Plus_Jakarta_Sans',sans-serif]">
                <p>{AGENCY_INFO.address.line1}</p>
                <p>{AGENCY_INFO.address.line2}</p>
                <p>{AGENCY_INFO.address.city}</p>
                <p className="pt-1 text-[#FFF8F3] font-mono text-xs">{AGENCY_INFO.phone}</p>
              </div>
            </div>

            {/* GROUP 3: Follow Us */}
            <div
              className={`transition-all duration-700 delay-400 ${
                isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <h3 className="font-['Marcellus',serif] text-2xl sm:text-[28px] lg:text-[32px] text-[#FFF8F3] tracking-tight uppercase mb-4">
                Follow Us
              </h3>
              <div className="flex flex-wrap gap-x-6 gap-y-2 text-xs sm:text-sm text-[#B8B8C2]">
                {AGENCY_INFO.socials.map((social) => (
                  <a
                    key={social.name}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 hover:text-[#F74300] transition-colors py-0.5"
                  >
                    <span>{social.name}</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-[#B8B8C2] group-hover:text-[#F74300]" />
                  </a>
                ))}
              </div>
            </div>
          </div>

          <div
            className={`flex justify-end pt-8 transition-all duration-700 delay-500 ${
              isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <button
              onClick={handleBackToTop}
              aria-label="Back to top of page"
              className="w-11 h-11 bg-[#F74300] hover:bg-[#FF5514] text-white rounded-lg flex items-center justify-center transition-all duration-300 shadow-md shadow-[#F74300]/30 active:scale-95 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <ArrowUp className="w-5 h-5 stroke-[2.5]" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
