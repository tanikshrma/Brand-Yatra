import React, { useState } from 'react';
import { ArrowUpRight, Users, Briefcase, Calendar, CheckCircle2, AlertCircle } from 'lucide-react';
import { HERO_STATS } from '../data/agencyData';

import { BtnShape } from './BtnShape';

interface HeroProps {
  onSuccessSubmit: (formData: { name: string; email: string; phone: string; service: string }) => void;
}

export const Hero: React.FC<HeroProps> = ({ onSuccessSubmit }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: 'Digital Marketing & Growth',
    budget: '$5,000 - $10,000/mo',
    goals: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Business / Name is required';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (formData.phone.trim().length < 8) {
      newErrors.phone = 'Please enter a valid phone number';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Business email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid corporate email';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      onSuccessSubmit({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        service: formData.service,
      });
    }, 700);
  };

  return (
    <section className="relative pt-32 pb-20 lg:pt-36 lg:pb-24 bg-[#191919] overflow-hidden">
      {/* Background architectural ambiance */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#FFF8F3_1px,transparent_1px)] [background-size:24px_24px]" />
      <div className="absolute top-1/4 -left-48 w-96 h-96 bg-[#F74300]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-0 w-80 h-80 bg-[#FFE4D6]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-start">
          {/* Left Column: Hero Copy & Statistics */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-2.5 mb-6">
              <span className="w-2 h-2 rounded-full bg-[#F74300] animate-pulse" />
              <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#FFE4D6]">
                CREATIVE DIGITAL AGENCY
              </span>
            </div>

            {/* Headline with Marcellus Serif */}
            <h1 className="font-['Marcellus',serif] text-4xl sm:text-5xl md:text-6xl text-[#FFF8F3] tracking-tight leading-[1.1] uppercase mb-6">
              DIGITAL MARKETING &amp;{' '}
              <span className="text-[#F74300] inline-block">BRAND GROWTH</span>{' '}
              AGENCY
            </h1>

            {/* Supporting Copy */}
            <p className="font-['Plus_Jakarta_Sans',sans-serif] text-base sm:text-lg text-[#B8B8C2] leading-relaxed max-w-2xl mb-8 font-normal">
              We help ambitious businesses build stronger brands, reach the right
              audiences, and generate measurable growth through creative strategy and
              digital marketing across Google, paid media, and high-impact digital experiences.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4 mb-14">
              <a
                href="#strategy-form"
                className="group relative inline-flex items-center justify-center gap-2.5 text-white font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm font-bold uppercase tracking-wider px-7 sm:px-8 py-4 transition-all duration-200 active:scale-95 filter drop-shadow-[0_8px_16px_rgba(247,67,0,0.25)]"
              >
                <BtnShape fill="#F74300" />
                <span className="relative z-10">LET'S TALK ABOUT GROWTH</span>
                <ArrowUpRight className="relative z-10 w-4 h-4 stroke-[2.5]" />
              </a>

              <a
                href="#portfolio"
                className="group relative inline-flex items-center justify-center gap-2.5 text-[#FFF8F3] font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm font-bold uppercase tracking-wider px-7 sm:px-8 py-4 transition-all duration-200 active:scale-95"
              >
                <BtnShape fill="#222222" />
                <span className="relative z-10">EXPLORE OUR WORK</span>
                <ArrowUpRight className="relative z-10 w-4 h-4 stroke-[2]" />
              </a>
            </div>

            {/* Three Compact Metrics with Marcellus */}
            <div className="pt-8 border-t border-[#333333] grid grid-cols-3 gap-4 sm:gap-8 max-w-xl">
              {HERO_STATS.map((stat, idx) => (
                <div key={idx} className="flex flex-col">
                  <div className="flex items-center gap-2 mb-1.5">
                    {idx === 0 && <Users className="w-4 h-4 text-[#F74300]" />}
                    {idx === 1 && <Briefcase className="w-4 h-4 text-[#F74300]" />}
                    {idx === 2 && <Calendar className="w-4 h-4 text-[#F74300]" />}
                    <span className="font-['Marcellus',serif] text-2xl sm:text-3xl text-[#FFF8F3]">
                      {stat.value}
                    </span>
                  </div>
                  <span className="text-[11px] sm:text-xs uppercase tracking-wider text-[#B8B8C2] font-medium">
                    {stat.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Enquiry Form Card */}
          <div
            id="strategy-form"
            className="lg:col-span-5 bg-[#222222] border border-[#333333] rounded-2xl p-6 sm:p-8 shadow-2xl relative"
          >
            {/* Header of Form with Marcellus */}
            <div className="mb-6">
              <h2 className="font-['Marcellus',serif] text-xl sm:text-2xl text-[#FFF8F3] tracking-wide mb-1.5 uppercase">
                Get Your Growth Strategy
              </h2>
              <p className="text-xs text-[#B8B8C2] leading-relaxed font-['Plus_Jakarta_Sans',sans-serif]">
                Tell us about your business. Our team will review your requirement and
                contact you.
              </p>
            </div>

            {submitted ? (
              <div className="py-10 text-center animate-in fade-in duration-300">
                <div className="w-14 h-14 bg-[#F74300]/15 border border-[#F74300]/30 text-[#F74300] rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-['Marcellus',serif] text-xl text-[#FFF8F3] mb-2 uppercase">
                  Strategy Request Received!
                </h3>
                <p className="text-xs text-[#B8B8C2] mb-6 max-w-xs mx-auto leading-relaxed">
                  Thank you, <strong className="text-[#FFF8F3]">{formData.name}</strong>.
                  Our senior growth strategist will audit your domain and reach out at{' '}
                  <span className="text-[#F74300]">{formData.email}</span> within 24 hours.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({
                      name: '',
                      phone: '',
                      email: '',
                      service: 'Digital Marketing & Growth',
                      budget: '$5,000 - $10,000/mo',
                      goals: '',
                    });
                  }}
                  className="text-xs font-semibold text-[#B8B8C2] hover:text-[#FFF8F3] underline uppercase tracking-wider"
                >
                  Submit another inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 font-['Plus_Jakarta_Sans',sans-serif]">
                {/* Full Name / Business */}
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                    Business / Company Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => {
                      setFormData({ ...formData, name: e.target.value });
                      if (errors.name) setErrors({ ...errors, name: '' });
                    }}
                    placeholder="e.g. Acme Technologies Ltd"
                    className={`w-full bg-[#191919] border ${
                      errors.name ? 'border-red-500' : 'border-[#333333]'
                    } rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-[#FFF8F3] placeholder-[#B8B8C2]/50 focus:outline-none focus:border-[#F74300] transition-colors`}
                  />
                  {errors.name && (
                    <span className="text-[10px] text-red-400 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> {errors.name}
                    </span>
                  )}
                </div>

                {/* Phone & Email Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => {
                        setFormData({ ...formData, phone: e.target.value });
                        if (errors.phone) setErrors({ ...errors, phone: '' });
                      }}
                      placeholder="+1 (555) 000-0000"
                      className={`w-full bg-[#191919] border ${
                        errors.phone ? 'border-red-500' : 'border-[#333333]'
                      } rounded-lg px-3 py-2.5 text-xs sm:text-sm text-[#FFF8F3] placeholder-[#B8B8C2]/50 focus:outline-none focus:border-[#F74300] transition-colors`}
                    />
                    {errors.phone && (
                      <span className="text-[10px] text-red-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.phone}
                      </span>
                    )}
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                      Business Email *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => {
                        setFormData({ ...formData, email: e.target.value });
                        if (errors.email) setErrors({ ...errors, email: '' });
                      }}
                      placeholder="alex@company.com"
                      className={`w-full bg-[#191919] border ${
                        errors.email ? 'border-red-500' : 'border-[#333333]'
                      } rounded-lg px-3 py-2.5 text-xs sm:text-sm text-[#FFF8F3] placeholder-[#B8B8C2]/50 focus:outline-none focus:border-[#F74300] transition-colors`}
                    />
                    {errors.email && (
                      <span className="text-[10px] text-red-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.email}
                      </span>
                    )}
                  </div>
                </div>

                {/* Service Required */}
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                    Service Required
                  </label>
                  <select
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    className="w-full bg-[#191919] border border-[#333333] rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-[#FFF8F3] focus:outline-none focus:border-[#F74300] transition-colors cursor-pointer"
                  >
                    <option value="Digital Marketing & Growth">Digital Marketing &amp; Growth</option>
                    <option value="Google Ads & PPC Campaigns">Google Ads &amp; PPC Campaigns</option>
                    <option value="SEO & Generative Engine Optimization">Search Engine Optimization (SEO &amp; GEO)</option>
                    <option value="Brand Strategy & Visual Identity">Brand Strategy &amp; Visual Identity</option>
                    <option value="Social Media Marketing">Social Media Marketing &amp; Community</option>
                    <option value="High-Converting Web Design">High-Converting Web Design &amp; Dev</option>
                    <option value="Full Omnichannel Growth Package">Full Omnichannel Growth Package</option>
                  </select>
                </div>

                {/* Monthly Marketing Budget */}
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                    Monthly Marketing Budget
                  </label>
                  <select
                    value={formData.budget}
                    onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                    className="w-full bg-[#191919] border border-[#333333] rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-[#FFF8F3] focus:outline-none focus:border-[#F74300] transition-colors cursor-pointer"
                  >
                    <option value="$2,500 - $5,000/mo">$2,500 – $5,000 / month</option>
                    <option value="$5,000 - $10,000/mo">$5,000 – $10,000 / month</option>
                    <option value="$10,000 - $25,000/mo">$10,000 – $25,000 / month</option>
                    <option value="$25,000+/mo">$25,000+ / month (Enterprise)</option>
                  </select>
                </div>

                {/* What do you want to achieve */}
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                    What do you want to achieve?
                  </label>
                  <input
                    type="text"
                    value={formData.goals}
                    onChange={(e) => setFormData({ ...formData, goals: e.target.value })}
                    placeholder="e.g. 3x qualified leads, lower CPA, rebrand"
                    className="w-full bg-[#191919] border border-[#333333] rounded-lg px-3.5 py-2 text-xs sm:text-sm text-[#FFF8F3] placeholder-[#B8B8C2]/50 focus:outline-none focus:border-[#F74300] transition-colors"
                  />
                </div>

                {/* Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="group relative w-full inline-flex items-center justify-center text-white font-['Plus_Jakarta_Sans',sans-serif] font-bold text-xs sm:text-sm uppercase tracking-wider py-4 transition-all duration-200 active:scale-[0.99] cursor-pointer mt-2 filter drop-shadow-[0_4px_12px_rgba(247,67,0,0.25)]"
                >
                  <BtnShape fill="#F74300" />
                  <span className="relative z-10">{isSubmitting ? 'PREPARING AUDIT...' : 'GET MY STRATEGY'}</span>
                </button>

                <p className="text-[10px] text-center text-[#B8B8C2]/80 pt-1">
                  No fixed packages. Strategy based on your business goals.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
