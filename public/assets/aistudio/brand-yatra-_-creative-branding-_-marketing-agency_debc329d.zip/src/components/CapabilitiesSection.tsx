import React, { useState } from 'react';
import { CAPABILITY_TAGS } from '../data/agencyData';
import { Sparkles, ArrowRight } from 'lucide-react';

interface CapabilitiesSectionProps {
  onOpenConsultation: () => void;
}

export const CapabilitiesSection: React.FC<CapabilitiesSectionProps> = ({ onOpenConsultation }) => {
  const [activeTag, setActiveTag] = useState<string | null>(CAPABILITY_TAGS[0].id);

  const selectedCapability = CAPABILITY_TAGS.find((t) => t.id === activeTag);

  return (
    <section id="capabilities" className="py-24 bg-[#191919] text-[#FFF8F3] relative overflow-hidden">
      {/* Background glow with warm orange tint */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-[#F74300]/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Prominent Center Heading with Marcellus */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 mb-4">
            <span className="w-2 h-2 rounded-full bg-[#F74300]" />
            <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#FFE4D6]">
              COMPREHENSIVE CAPABILITIES
            </span>
          </div>

          <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl text-[#FFF8F3] uppercase tracking-tight leading-[1.15] mb-5">
            GET FOUND. GET CHOSEN.{' '}
            <span className="text-[#F74300] block sm:inline">GROW FASTER.</span>
          </h2>

          <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm text-[#B8B8C2] leading-relaxed max-w-xl mx-auto">
            From brand positioning to performance campaigns, we bring your marketing
            channels together to build a stronger digital presence.
          </p>
        </div>

        {/* Orange Outlined Pill Labels in Centered Rows */}
        <div className="flex flex-wrap justify-center gap-3 sm:gap-4 max-w-5xl mx-auto mb-10">
          {CAPABILITY_TAGS.map((tag) => {
            const isSelected = activeTag === tag.id;
            return (
              <button
                key={tag.id}
                onClick={() => setActiveTag(tag.id)}
                className={`transition-all duration-200 font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm font-semibold tracking-wider uppercase px-5 sm:px-6 py-2.5 sm:py-3 rounded-full border cursor-pointer ${
                  isSelected
                    ? 'border-[#F74300] bg-[#F74300] text-white shadow-lg shadow-[#F74300]/30 scale-105'
                    : 'border-[#F74300]/60 text-[#FFF8F3] bg-[#222222]/50 hover:bg-[#F74300]/10 hover:border-[#F74300] hover:scale-[1.02]'
                }`}
              >
                {tag.name}
              </button>
            );
          })}
        </div>

        {/* Selected Capability Interactive Detail Drawer */}
        {selectedCapability && (
          <div className="max-w-xl mx-auto bg-[#222222] border border-[#333333] rounded-2xl p-6 text-center animate-in fade-in duration-200">
            <div className="inline-flex items-center gap-1.5 text-[#F74300] text-[11px] font-bold uppercase tracking-wider mb-2 font-['Plus_Jakarta_Sans',sans-serif]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Agency Channel Focus</span>
            </div>
            <h3 className="font-['Marcellus',serif] text-xl text-[#FFF8F3] uppercase mb-2">
              {selectedCapability.name}
            </h3>
            <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs text-[#B8B8C2] leading-relaxed mb-4">
              {selectedCapability.desc}
            </p>
            <button
              onClick={onOpenConsultation}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#F74300] hover:text-[#FFE4D6] uppercase tracking-wider font-['Plus_Jakarta_Sans',sans-serif]"
            >
              <span>Deploy {selectedCapability.name} for your brand</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
