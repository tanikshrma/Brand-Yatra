import React, { useState } from 'react';
import { ArrowUpRight, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';
import { SERVICES_LIST } from '../data/agencyData';
import { BtnShape } from './BtnShape';

interface ContactSectionProps {
  onSuccessSubmit: (data: { name: string; email: string }) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onSuccessSubmit }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    service: 'Full Omnichannel Growth Package',
    details: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const err: Record<string, string> = {};
    if (!formData.name.trim()) err.name = 'Full name is required';
    if (!formData.email.trim()) {
      err.email = 'Business email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      err.email = 'Please provide a valid email';
    }
    if (!formData.phone.trim()) {
      err.phone = 'Phone number is required';
    }
    if (!formData.company.trim()) {
      err.company = 'Company name is required';
    }
    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      onSuccessSubmit({ name: formData.name, email: formData.email });
    }, 600);
  };

  return (
    <section id="contact" className="py-24 bg-[#191919] text-[#FFF8F3] relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#F74300]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Form */}
          <div className="lg:col-span-7 bg-[#222222] border border-[#333333] rounded-3xl p-8 sm:p-10 shadow-2xl">
            <div className="mb-8">
              <div className="inline-flex items-center gap-2 mb-3">
                <span className="w-2 h-2 rounded-full bg-[#F74300]" />
                <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#FFE4D6]">
                  LET'S GROW
                </span>
              </div>
              <h2 className="font-['Marcellus',serif] text-2xl sm:text-3xl md:text-4xl text-[#FFF8F3] uppercase tracking-tight mb-3">
                TELL US ABOUT YOUR <span className="text-[#F74300]">GROWTH GOALS</span>
              </h2>
              <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm text-[#B8B8C2] leading-relaxed">
                Share a little about your business and what you want to achieve. Let's explore
                how Brand Yatra can help you scale.
              </p>
            </div>

            {submitted ? (
              <div className="py-12 text-center animate-in fade-in duration-300">
                <div className="w-16 h-16 bg-[#F74300]/15 border border-[#F74300]/40 text-[#F74300] rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-9 h-9" />
                </div>
                <h3 className="font-['Marcellus',serif] text-2xl text-white mb-2 uppercase">
                  Enquiry Transmitted Successfully
                </h3>
                <p className="font-['Plus_Jakarta_Sans',sans-serif] text-sm text-[#B8B8C2] max-w-md mx-auto mb-6 leading-relaxed">
                  Thank you, <strong className="text-white">{formData.name}</strong> from{' '}
                  <strong className="text-white">{formData.company}</strong>. Our team has received
                  your project brief and will return an initial roadmap within 24 business hours.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({
                      name: '',
                      email: '',
                      phone: '',
                      company: '',
                      service: 'Full Omnichannel Growth Package',
                      details: '',
                    });
                  }}
                  className="font-['Plus_Jakarta_Sans',sans-serif] text-xs font-semibold text-[#F74300] hover:underline uppercase tracking-wider cursor-pointer"
                >
                  Send another inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 font-['Plus_Jakarta_Sans',sans-serif]">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => {
                        setFormData({ ...formData, name: e.target.value });
                        if (errors.name) setErrors({ ...errors, name: '' });
                      }}
                      placeholder="e.g. Maya Sharma"
                      className={`w-full bg-[#191919] border ${
                        errors.name ? 'border-red-500' : 'border-[#333333]'
                      } rounded-xl px-4 py-3 text-xs sm:text-sm text-[#FFF8F3] placeholder-[#B8B8C2]/50 focus:outline-none focus:border-[#F74300] transition-colors`}
                    />
                    {errors.name && (
                      <span className="text-[10px] text-red-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.name}
                      </span>
                    )}
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                      Business Email *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => {
                        setFormData({ ...formData, email: e.target.value });
                        if (errors.email) setErrors({ ...errors, email: '' });
                      }}
                      placeholder="maya@enterprise.com"
                      className={`w-full bg-[#191919] border ${
                        errors.email ? 'border-red-500' : 'border-[#333333]'
                      } rounded-xl px-4 py-3 text-xs sm:text-sm text-[#FFF8F3] placeholder-[#B8B8C2]/50 focus:outline-none focus:border-[#F74300] transition-colors`}
                    />
                    {errors.email && (
                      <span className="text-[10px] text-red-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.email}
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => {
                        setFormData({ ...formData, phone: e.target.value });
                        if (errors.phone) setErrors({ ...errors, phone: '' });
                      }}
                      placeholder="+91 98765 43210"
                      className={`w-full bg-[#191919] border ${
                        errors.phone ? 'border-red-500' : 'border-[#333333]'
                      } rounded-xl px-4 py-3 text-xs sm:text-sm text-[#FFF8F3] placeholder-[#B8B8C2]/50 focus:outline-none focus:border-[#F74300] transition-colors`}
                    />
                    {errors.phone && (
                      <span className="text-[10px] text-red-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.phone}
                      </span>
                    )}
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                      Company Name *
                    </label>
                    <input
                      type="text"
                      value={formData.company}
                      onChange={(e) => {
                        setFormData({ ...formData, company: e.target.value });
                        if (errors.company) setErrors({ ...errors, company: '' });
                      }}
                      placeholder="e.g. Horizon Labs"
                      className={`w-full bg-[#191919] border ${
                        errors.company ? 'border-red-500' : 'border-[#333333]'
                      } rounded-xl px-4 py-3 text-xs sm:text-sm text-[#FFF8F3] placeholder-[#B8B8C2]/50 focus:outline-none focus:border-[#F74300] transition-colors`}
                    />
                    {errors.company && (
                      <span className="text-[10px] text-red-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.company}
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                    Service Required
                  </label>
                  <select
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    className="w-full bg-[#191919] border border-[#333333] rounded-xl px-4 py-3 text-xs sm:text-sm text-[#FFF8F3] focus:outline-none focus:border-[#F74300] transition-colors cursor-pointer"
                  >
                    <option value="Full Omnichannel Growth Package">Full Omnichannel Growth Package</option>
                    {SERVICES_LIST.map((s) => (
                      <option key={s.id} value={s.title}>
                        {s.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#B8B8C2] mb-1.5">
                    Project Details &amp; Target Timelines
                  </label>
                  <textarea
                    rows={3}
                    value={formData.details}
                    onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                    placeholder="Tell us about your target audience, current CAC/ROAS challenges, and growth goals..."
                    className="w-full bg-[#191919] border border-[#333333] rounded-xl px-4 py-3 text-xs sm:text-sm text-[#FFF8F3] placeholder-[#B8B8C2]/50 focus:outline-none focus:border-[#F74300] transition-colors resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="group/btn relative w-full inline-flex items-center justify-center gap-2 text-white font-['Plus_Jakarta_Sans',sans-serif] font-bold text-xs sm:text-sm uppercase tracking-wider py-4 transition-all duration-200 filter drop-shadow-[0_8px_20px_rgba(247,67,0,0.3)] active:scale-[0.99] cursor-pointer mt-2 disabled:opacity-75"
                >
                  <BtnShape fill="#F74300" />
                  <span className="relative z-10">{isSubmitting ? 'TRANSMITTING...' : 'SEND YOUR ENQUIRY'}</span>
                  <ArrowUpRight className="relative z-10 w-4 h-4 stroke-[2.5]" />
                </button>
              </form>
            )}
          </div>

          {/* Right Column: Bold Orange Geometric SVG Visual */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center text-center">
            <div className="w-64 h-64 sm:w-80 sm:h-80 relative flex items-center justify-center mb-8">
              <svg
                viewBox="0 0 300 300"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="w-full h-full drop-shadow-[0_20px_50px_rgba(247,67,0,0.25)]"
              >
                {/* Outer Bold Angular Polygon in #F74300 */}
                <path
                  d="M150 25L275 240H25L150 25Z"
                  fill="#F74300"
                />
                {/* Inner Cutout Geometric Facet */}
                <path
                  d="M150 95L215 210H85L150 95Z"
                  fill="#191919"
                />
                {/* Secondary Offset Accent Wedge */}
                <polygon
                  points="150,135 185,195 115,195"
                  fill="#FFE4D6"
                />
                <circle cx="150" cy="172" r="12" fill="#FFFFFF" />
              </svg>
            </div>

            <div className="max-w-sm">
              <span className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-widest text-[#F74300] mb-2 font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AGENCY CREED</span>
              </span>
              <p className="font-['Marcellus',serif] text-xl sm:text-2xl text-[#FFF8F3] leading-snug">
                "We engineer unfair advantages for forward-thinking brands."
              </p>
              <div className="w-12 h-1 bg-[#F74300] mx-auto mt-4 rounded-full" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
