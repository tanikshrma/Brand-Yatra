import React from 'react';

// Upper Strip Logos (Displayed on dark charcoal background with light silver/orange accents)
const UPPER_STRIP_LOGOS = [
  {
    id: 'bepractical',
    render: () => (
      <div className="flex items-center gap-2.5">
        <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8 text-[#FFF8F3]" aria-hidden="true">
          <circle cx="20" cy="11" r="3.5" fill="currentColor" />
          <path
            d="M8 28C10 21 16 17 20 17C24 17 30 21 32 28M15 34C17 31 19 28 20 28C21 28 23 31 25 34"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
        <div className="flex flex-col text-left">
          <span className="font-['Plus_Jakarta_Sans',sans-serif] font-bold text-base sm:text-lg text-[#FFF8F3] tracking-tight leading-none">
            Be Practical<sup className="text-[9px] font-normal">®</sup>
          </span>
          <span className="text-[8px] sm:text-[9px] font-mono uppercase tracking-[0.25em] text-[#A7A7AD] mt-1">
            TECH SOLUTIONS
          </span>
        </div>
      </div>
    ),
  },
  {
    id: 'fipola',
    render: () => (
      <div className="flex items-center gap-1.5">
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-2xl sm:text-3xl tracking-tight text-[#FFF8F3] flex items-center">
          f
          <span className="relative inline-flex items-center justify-center">
            <span className="w-1.5 h-1.5 bg-[#F74300] rounded-sm absolute -top-1" />
            i
          </span>
          pola
        </span>
        <span className="text-[8px] font-mono text-[#F74300] border border-[#F74300]/40 px-1.5 py-0.5 rounded ml-1">
          DTC
        </span>
      </div>
    ),
  },
  {
    id: 'saloncentric',
    render: () => (
      <div className="flex items-center gap-2">
        <svg viewBox="0 0 36 36" fill="none" className="w-7 h-7 text-[#FFF8F3]" aria-hidden="true">
          <circle cx="18" cy="18" r="16" stroke="currentColor" strokeWidth="2.5" strokeDasharray="6 3" />
          <circle cx="18" cy="18" r="10" stroke="#F74300" strokeWidth="2" />
          <circle cx="18" cy="18" r="4" fill="currentColor" />
        </svg>
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-medium text-lg sm:text-xl text-[#FFF8F3] tracking-tight">
          SalonCentric<span className="text-[10px] text-[#A7A7AD]">™</span>
        </span>
      </div>
    ),
  },
  {
    id: 'hsbc',
    render: () => (
      <div className="flex items-center gap-2.5">
        <div className="relative w-6 h-6 flex items-center justify-center">
          <div className="w-3 h-3 bg-[#F74300] transform rotate-45" />
          <div className="absolute w-2 h-2 bg-white transform rotate-45" />
        </div>
        <div className="flex flex-col text-left">
          <span className="font-['Marcellus',serif] font-bold text-lg sm:text-xl text-[#FFF8F3] tracking-widest leading-none">
            HSBC
          </span>
          <span className="text-[8px] font-mono tracking-widest text-[#A7A7AD]">
            GLOBAL WEALTH
          </span>
        </div>
      </div>
    ),
  },
  {
    id: 'technova',
    render: () => (
      <div className="flex items-center gap-2">
        <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6 text-[#F74300]" aria-hidden="true">
          <polygon points="16,3 28,10 28,22 16,29 4,22 4,10" stroke="currentColor" strokeWidth="2" />
          <circle cx="16" cy="16" r="3" fill="#FFF8F3" />
        </svg>
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-extrabold text-base sm:text-lg text-[#FFF8F3] tracking-wider uppercase">
          TECHNOVA<span className="text-[#F74300]">.AI</span>
        </span>
      </div>
    ),
  },
  {
    id: 'deforet',
    render: () => (
      <div className="flex items-center gap-2">
        <svg viewBox="0 0 30 30" fill="none" className="w-6 h-6 text-[#FFF8F3]" aria-hidden="true">
          <path d="M15 3C15 15 3 15 3 15C3 15 15 15 15 27C15 15 27 15 27 15C27 15 15 15 15 3Z" fill="#F74300" />
        </svg>
        <span className="font-['Marcellus',serif] text-base sm:text-lg text-[#FFF8F3] tracking-widest uppercase">
          DEFÖRET BOTANICALS
        </span>
      </div>
    ),
  },
  {
    id: 'cesce',
    render: () => (
      <div className="flex items-center gap-2">
        <div className="w-6 h-6 rounded-md bg-[#F74300]/20 border border-[#F74300] flex items-center justify-center font-bold text-xs text-[#F74300]">
          C
        </div>
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-bold text-base sm:text-lg text-[#FFF8F3] tracking-wider">
          CESCE GROUP
        </span>
      </div>
    ),
  },
  {
    id: 'apex',
    render: () => (
      <div className="flex items-center gap-2">
        <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6 text-[#FFF8F3]" aria-hidden="true">
          <path d="M16 4L28 26H4L16 4Z" stroke="currentColor" strokeWidth="2" />
          <path d="M16 14L22 26H10L16 14Z" fill="#F74300" />
        </svg>
        <span className="font-['Marcellus',serif] text-base sm:text-lg text-[#FFF8F3] tracking-widest uppercase">
          APEX HORIZON
        </span>
      </div>
    ),
  },
];

// Lower Strip Logos (Displayed on Brand Yatra Orange background with dark charcoal/black icons & typography)
const LOWER_STRIP_LOGOS = [
  {
    id: 'stethcare',
    render: () => (
      <div className="flex items-center bg-[#111215] text-white px-4 py-2 rounded-lg shadow-md border border-black/40">
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-sm sm:text-base tracking-wider uppercase pr-2">
          STETH
        </span>
        {/* Central emblem matching reference */}
        <div className="w-6 h-6 bg-[#F74300] rounded-sm flex items-center justify-center mx-1">
          <svg viewBox="0 0 20 20" fill="none" className="w-4 h-4 text-white" aria-hidden="true">
            <path
              d="M10 2C10 6 6 8 6 11C6 14 8 16 10 18C12 16 14 14 14 11C14 8 10 6 10 2Z"
              fill="currentColor"
            />
          </svg>
        </div>
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-sm sm:text-base tracking-wider uppercase pl-2">
          CARE
        </span>
      </div>
    ),
  },
  {
    id: 'coffeemug',
    render: () => (
      <div className="flex items-center gap-2 text-[#111215]">
        <svg viewBox="0 0 28 28" fill="none" className="w-6 h-6 text-[#111215]" aria-hidden="true">
          <path
            d="M6 10H20V18C20 21 17 23 13 23C9 23 6 21 6 18V10Z"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <path d="M20 12H22C23.5 12 24.5 13 24.5 14.5C24.5 16 23.5 17 22 17H20" stroke="currentColor" strokeWidth="2.5" />
          <path d="M10 5V7M14 4V7M18 5V7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-xl sm:text-2xl tracking-widest text-[#111215]">
          C<span className="relative inline-flex items-center justify-center">
            <span className="w-1.5 h-1.5 bg-[#111215] rounded-full absolute -top-1" />
            O
          </span>
          FFEE MUG
        </span>
      </div>
    ),
  },
  {
    id: 'saloncentric-dark',
    render: () => (
      <div className="flex items-center gap-2 text-[#111215]">
        <svg viewBox="0 0 36 36" fill="none" className="w-7 h-7 text-[#111215]" aria-hidden="true">
          <circle cx="18" cy="18" r="16" stroke="currentColor" strokeWidth="3" strokeDasharray="6 3" />
          <circle cx="18" cy="18" r="10" stroke="currentColor" strokeWidth="2.5" />
          <circle cx="18" cy="18" r="4" fill="currentColor" />
        </svg>
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-bold text-xl sm:text-2xl text-[#111215] tracking-tight">
          SalonCentric<span className="text-[10px]">™</span>
        </span>
      </div>
    ),
  },
  {
    id: 'oneplus',
    render: () => (
      <div className="flex items-center gap-2.5 text-[#111215]">
        <div className="w-7 h-7 bg-[#111215] text-[#F74300] font-black text-xs flex items-center justify-center rounded-md border border-black/40">
          1+
        </div>
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-extrabold text-lg sm:text-xl text-[#111215] tracking-tight">
          ONEPLUS TECH
        </span>
      </div>
    ),
  },
  {
    id: 'sobha',
    render: () => (
      <div className="flex items-center gap-2 text-[#111215]">
        <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6 text-[#111215]" aria-hidden="true">
          <path d="M4 24L8 10L16 16L24 10L28 24H4Z" stroke="currentColor" strokeWidth="2.5" fill="currentColor" fillOpacity="0.2" />
          <circle cx="8" cy="8" r="2" fill="currentColor" />
          <circle cx="16" cy="13" r="2" fill="currentColor" />
          <circle cx="24" cy="8" r="2" fill="currentColor" />
        </svg>
        <span className="font-['Marcellus',serif] font-bold text-lg sm:text-xl text-[#111215] tracking-widest uppercase">
          SOBHA LIMITED
        </span>
      </div>
    ),
  },
  {
    id: 'conceptcity',
    render: () => (
      <div className="flex items-center gap-2 text-[#111215]">
        <div className="flex flex-col gap-0.5">
          <div className="flex gap-0.5">
            <span className="w-2 h-2 bg-[#111215]" />
            <span className="w-2 h-2 bg-[#111215]" />
          </div>
          <div className="flex gap-0.5">
            <span className="w-2 h-2 bg-[#111215]" />
            <span className="w-2 h-2 bg-transparent border border-[#111215]" />
          </div>
        </div>
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-extrabold text-base sm:text-lg text-[#111215] tracking-wider uppercase">
          CONCEPT CITY
        </span>
      </div>
    ),
  },
  {
    id: 'srm',
    render: () => (
      <div className="flex items-center gap-2 text-[#111215]">
        <svg viewBox="0 0 30 30" fill="none" className="w-6 h-6 text-[#111215]" aria-hidden="true">
          <path
            d="M15 3L25 9V17C25 22 15 27 15 27C15 27 5 22 5 17V9L15 3Z"
            stroke="currentColor"
            strokeWidth="2.5"
          />
          <path d="M15 8V18M10 13H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
        <span className="font-['Marcellus',serif] font-bold text-base sm:text-lg text-[#111215] tracking-wider uppercase">
          SRM CAMPUS
        </span>
      </div>
    ),
  },
  {
    id: 'urbancraft',
    render: () => (
      <div className="flex items-center gap-2 text-[#111215]">
        <div className="w-5 h-5 border-2 border-[#111215] rotate-45 flex items-center justify-center">
          <span className="w-1.5 h-1.5 bg-[#111215]" />
        </div>
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-base sm:text-lg text-[#111215] tracking-widest uppercase">
          URBAN CRAFT
        </span>
      </div>
    ),
  },
];

export const DiagonalMarquee: React.FC = () => {
  return (
    <section
      aria-label="Partner Brands Diagonal Marquee"
      className="relative overflow-hidden w-full py-20 sm:py-24 md:py-28 bg-[#191A1F] select-none"
    >
      {/* Background ambient lighting */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(247,67,0,0.08),transparent_70%)] pointer-events-none" />
      <div className="absolute top-0 left-0 right-0 h-px bg-[#35363D]" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-[#35363D]" />

      <div className="relative space-y-6 sm:space-y-8">
        {/* UPPER STRIP: Dark charcoal surface, scrolling RIGHT TO LEFT, rotated 4.5deg */}
        <div
          className="relative will-change-transform"
          style={{
            transform: 'rotate(4.5deg)',
            width: '130%',
            marginLeft: '-15%',
          }}
        >
          <div
            className="relative h-18 sm:h-20 bg-[#1F2026] border-y border-[#35363D] flex items-center overflow-hidden z-0 shadow-lg"
            title="Clients & Partners"
          >
            <div className="animate-marquee-left flex items-center gap-10 sm:gap-14 px-6">
              {/* First sequence */}
              {UPPER_STRIP_LOGOS.map((item, idx) => (
                <div
                  key={`up-1-${idx}`}
                  className="flex-shrink-0 flex items-center transition-transform hover:scale-105 duration-200 cursor-default"
                >
                  {item.render()}
                </div>
              ))}
              {/* Duplicated sequence for seamless looping without jumps */}
              {UPPER_STRIP_LOGOS.map((item, idx) => (
                <div
                  key={`up-2-${idx}`}
                  className="flex-shrink-0 flex items-center transition-transform hover:scale-105 duration-200 cursor-default"
                  aria-hidden="true"
                >
                  {item.render()}
                </div>
              ))}
              {/* Tripled sequence for ultra-wide screen coverage */}
              {UPPER_STRIP_LOGOS.map((item, idx) => (
                <div
                  key={`up-3-${idx}`}
                  className="flex-shrink-0 flex items-center transition-transform hover:scale-105 duration-200 cursor-default"
                  aria-hidden="true"
                >
                  {item.render()}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* LOWER STRIP: Brand Yatra Orange #F74300, scrolling LEFT TO RIGHT, rotated -4.5deg */}
        <div
          className="relative will-change-transform z-10"
          style={{
            transform: 'rotate(-4.5deg)',
            width: '130%',
            marginLeft: '-15%',
          }}
        >
          <div
            className="relative h-20 sm:h-24 bg-[#F74300] flex items-center overflow-hidden z-10 shadow-[0_16px_36px_rgba(0,0,0,0.7)] ring-1 ring-black/20"
            title="Featured Collaborations"
          >
            <div className="animate-marquee-right flex items-center gap-10 sm:gap-14 px-6">
              {/* First sequence */}
              {LOWER_STRIP_LOGOS.map((item, idx) => (
                <div
                  key={`low-1-${idx}`}
                  className="flex-shrink-0 flex items-center transition-transform hover:scale-105 duration-200 cursor-default"
                >
                  {item.render()}
                </div>
              ))}
              {/* Duplicated sequence for seamless looping without jumps */}
              {LOWER_STRIP_LOGOS.map((item, idx) => (
                <div
                  key={`low-2-${idx}`}
                  className="flex-shrink-0 flex items-center transition-transform hover:scale-105 duration-200 cursor-default"
                  aria-hidden="true"
                >
                  {item.render()}
                </div>
              ))}
              {/* Tripled sequence for ultra-wide screen coverage */}
              {LOWER_STRIP_LOGOS.map((item, idx) => (
                <div
                  key={`low-3-${idx}`}
                  className="flex-shrink-0 flex items-center transition-transform hover:scale-105 duration-200 cursor-default"
                  aria-hidden="true"
                >
                  {item.render()}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
