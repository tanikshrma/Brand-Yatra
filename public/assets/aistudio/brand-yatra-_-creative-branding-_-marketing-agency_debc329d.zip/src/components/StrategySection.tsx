import React from 'react';
import { ArrowUpRight, Search, Target, Share2, Sparkles } from 'lucide-react';
import { STRATEGY_CARDS } from '../data/agencyData';
import { BtnShape } from './BtnShape';

interface StrategySectionProps {
  onOpenConsultation: () => void;
}

export const StrategySection: React.FC<StrategySectionProps> = ({ onOpenConsultation }) => {
  return (
    <section id="strategy" className="py-24 bg-[#FFF8F3] text-[#191919] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Number Badge & Eyebrow */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-7 h-7 rounded-full bg-[#191919] text-[#FFF8F3] text-xs font-bold flex items-center justify-center font-mono">
            1
          </div>
          <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#191919]/70">
            WHAT NEXT
          </span>
        </div>

        {/* Editorial Heading & Description with Marcellus */}
        <div className="max-w-4xl mb-16">
          <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl text-[#191919] tracking-tight leading-[1.15] mb-6">
            One growth strategy across google search, paid media, and social — focused on qualified leads, visibility, and measurable business outcomes.
          </h2>
          <p className="font-['Plus_Jakarta_Sans',sans-serif] text-sm sm:text-base text-[#191919]/80 max-w-2xl leading-relaxed">
            Connect search intent, paid acquisition, social engagement, and high-converting
            creative storytelling through one focused agency partner built around pipeline revenue.
          </p>
        </div>

        {/* Four Cards in a Horizontal Row without background or border */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {STRATEGY_CARDS.map((card, idx) => {
            if (card.isDark) {
              // Final Card: Distinctive Surface with Brand Yatra Orange Accent
              return (
                <div
                  key={card.id}
                  className="relative bg-transparent border-none p-7 sm:p-8 flex flex-col justify-between group transition-all duration-300 min-h-[400px]"
                >
                  <div className="relative z-10">
                    {/* Top Tag */}
                    <div className="inline-flex items-center gap-1.5 bg-[#F74300]/15 border border-[#F74300]/30 text-[#191919] text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-8 font-['Plus_Jakarta_Sans',sans-serif]">
                      <Sparkles className="w-3 h-3 text-[#F74300]" />
                      <span>GROW YOUR BUSINESS</span>
                    </div>

                    <h3 className="font-['Marcellus',serif] text-3xl sm:text-4xl text-[#191919] uppercase tracking-tight mb-4 group-hover:text-[#F74300] transition-colors">
                      {card.headline}
                    </h3>

                    <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs text-[#191919]/80 leading-relaxed mb-6">
                      {card.body}
                    </p>

                    <div className="space-y-1.5 mb-6 font-['Plus_Jakarta_Sans',sans-serif]">
                      {card.points.map((pt, i) => (
                        <div key={i} className="text-[11px] text-[#191919]/80 flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#F74300]" />
                          <span>{pt}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="relative z-10">
                    <button
                      onClick={onOpenConsultation}
                      className="group/btn relative w-full inline-flex items-center justify-between px-6 py-3.5 text-white font-['Plus_Jakarta_Sans',sans-serif] text-xs font-bold uppercase tracking-wider transition-all duration-200 active:scale-95 cursor-pointer filter drop-shadow-[0_8px_16px_rgba(247,67,0,0.25)]"
                    >
                      <BtnShape fill="#F74300" />
                      <span className="relative z-10">START YOUR AUDIT</span>
                      <div className="relative z-10 w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
                        <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                      </div>
                    </button>
                  </div>
                </div>
              );
            }

            // Cards 1-3: Without Background Color or Border Color
            return (
              <div
                key={card.id}
                className="group relative bg-transparent border-none p-7 sm:p-8 flex flex-col justify-between transition-all duration-300 min-h-[400px]"
              >
                <div className="relative z-10">
                  {/* Top pill label */}
                  <div className="text-center mb-8">
                    <span className="inline-block border border-[#F74300]/20 text-[#191919] font-['Plus_Jakarta_Sans',sans-serif] text-[10px] font-bold uppercase tracking-widest px-3.5 py-1 rounded-full bg-[#FFF8F3]">
                      {card.label}
                    </span>
                  </div>

                  {/* Icon */}
                  <div className="w-10 h-10 rounded-full bg-[#FFF1E8] border border-[#FFE4D6] flex items-center justify-center mx-auto mb-5 text-[#F74300]">
                    {idx === 0 && <Search className="w-4 h-4" />}
                    {idx === 1 && <Target className="w-4 h-4" />}
                    {idx === 2 && <Share2 className="w-4 h-4" />}
                  </div>

                  {/* Headline with Marcellus Serif */}
                  <h3 className="font-['Marcellus',serif] text-lg sm:text-xl text-[#191919] mb-2 text-center">
                    {card.headline}
                  </h3>
                  <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs text-[#191919]/75 leading-relaxed text-center mb-5">
                    {card.body}
                  </p>
                </div>

                {/* Bottom Action Icon button */}
                <div className="relative z-10 flex justify-center pt-4 border-t border-[#FFE4D6]">
                  <button
                    onClick={onOpenConsultation}
                    className="w-10 h-10 rounded-full border border-[#191919]/20 hover:border-[#F74300] hover:bg-[#F74300] hover:text-white text-[#191919] flex items-center justify-center transition-all duration-200 cursor-pointer"
                    aria-label={`Explore ${card.label}`}
                  >
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
