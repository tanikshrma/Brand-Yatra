import React from 'react';
import { ArrowUpRight, Globe, TrendingUp, Zap } from 'lucide-react';
import { BtnShape } from './BtnShape';

interface SelectedProjectsProps {
  onOpenConsultation: () => void;
}

export const SelectedProjects: React.FC<SelectedProjectsProps> = ({ onOpenConsultation }) => {
  const successItems = [
    {
      id: 'brand-web',
      tag: 'BRAND & WEB',
      icon: <Globe className="w-8 h-8 text-[#F74300] stroke-[1.8]" />,
      title: 'Digital Ecosystem & Brand Architecture',
      description: 'High-conversion digital flagship architecture and cohesive visual identity system delivering measurable pipeline growth.',
      stat: '240% Conversion Lift',
    },
    {
      id: 'organic-paid',
      tag: 'ORGANIC & PAID',
      icon: <TrendingUp className="w-8 h-8 text-[#F74300] stroke-[1.8]" />,
      title: 'Search Domination & Paid Acquisition',
      description: 'Integrated omnichannel search engine optimization and targeted meta acquisition scaling organic visibility and qualified leads.',
      stat: '340+ Admissions',
    },
    {
      id: 'performance-ppc',
      tag: 'PERFORMANCE PPC',
      icon: <Zap className="w-8 h-8 text-[#F74300] stroke-[1.8]" />,
      title: 'High-Intent Customer Performance Media',
      description: 'Laser-targeted search PPC and retargeting workflows acquiring high-LTV customers while slashing CPA by over 42%.',
      stat: '7.8x Audited ROAS',
    },
  ];

  return (
    <section className="py-24 bg-[#FFF8F3] text-[#191919] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Number Badge & Eyebrow */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-7 h-7 rounded-full bg-[#191919] text-[#FFF8F3] text-xs font-bold flex items-center justify-center font-mono">
            5
          </div>
          <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#191919]/70">
            OUR WORKS
          </span>
        </div>

        {/* Section Heading with Marcellus */}
        <div className="max-w-3xl mb-16">
          <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl text-[#191919] tracking-tight uppercase leading-[1.15] mb-4">
            SUCCESS STORIES
          </h2>
          <p className="font-['Plus_Jakarta_Sans',sans-serif] text-sm sm:text-base text-[#191919]/80 leading-relaxed">
            Proven commercial milestones achieved through disciplined strategy, technical SEO,
            and high-converting creative execution.
          </p>
        </div>

        {/* Three Cards without Background or Border Color */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-10 mb-14">
          {successItems.map((item) => (
            <div
              key={item.id}
              className="group relative bg-transparent border-none p-6 sm:p-7 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Related Icon Above Tag */}
                <div className="w-12 h-12 rounded-xl bg-[#FFF1E8] border border-[#FFE4D6] flex items-center justify-center mb-4 transition-transform group-hover:scale-110">
                  {item.icon}
                </div>

                {/* Service Tag */}
                <div className="mb-3">
                  <span className="text-[11px] font-bold uppercase tracking-widest text-[#F74300] font-['Plus_Jakarta_Sans',sans-serif] bg-[#FFF1E8] px-3 py-1 rounded-full border border-[#FFE4D6]">
                    {item.tag}
                  </span>
                </div>

                {/* Service Headline */}
                <h3 className="font-['Marcellus',serif] text-2xl text-[#191919] mb-3 group-hover:text-[#F74300] transition-colors leading-snug">
                  {item.title}
                </h3>

                {/* Description */}
                <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs text-[#191919]/80 leading-relaxed mb-6 font-normal">
                  {item.description}
                </p>
              </div>

              <div>
                {/* Stat Badge */}
                <div className="mb-6">
                  <span className="text-xs bg-[#191919] text-[#FFF8F3] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-full shadow-sm font-['Plus_Jakarta_Sans',sans-serif] inline-block">
                    {item.stat}
                  </span>
                </div>

                {/* Bottom Action Arrow */}
                <div className="pt-4 border-t border-[#191919]/15 flex items-center justify-between">
                  <span className="font-['Plus_Jakarta_Sans',sans-serif] text-[11px] font-semibold uppercase tracking-wider text-[#191919]/70 group-hover:text-[#191919] transition-colors">
                    Case Review
                  </span>
                  <button
                    onClick={onOpenConsultation}
                    className="w-10 h-10 rounded-full border border-[#191919]/20 group-hover:bg-[#F74300] group-hover:border-[#F74300] group-hover:text-white text-[#191919] flex items-center justify-center transition-all duration-200 cursor-pointer"
                    aria-label={`View details for ${item.title}`}
                  >
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Center CTA Button using BtnShape */}
        <div className="text-center">
          <button
            onClick={onOpenConsultation}
            className="group relative inline-flex items-center justify-center gap-2.5 text-white font-['Plus_Jakarta_Sans',sans-serif] text-xs font-bold uppercase tracking-wider px-8 py-4 transition-all duration-200 filter drop-shadow-[0_8px_20px_rgba(247,67,0,0.25)] hover:scale-105 active:scale-95 cursor-pointer"
          >
            <BtnShape fill="#F74300" />
            <span className="relative z-10">GET A STRATEGY CALL</span>
            <ArrowUpRight className="relative z-10 w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </section>
  );
};
