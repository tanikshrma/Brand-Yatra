import React, { useState, useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import { FullScreenMenu } from './FullScreenMenu';

interface HeaderProps {
  onOpenConsultation?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenConsultation }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const hamburgerRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'CORE SERVICES', href: '#services' },
    { name: 'WHAT WE DO', href: '#strategy' },
    { name: 'FEATURES', href: '#capabilities' },
    { name: 'PORTFOLIO', href: '#portfolio' },
    { name: 'OTHER SERVICES', href: '#process' },
    { name: 'CONTACT', href: '#contact' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#191919]/95 backdrop-blur-md border-b border-white/10 shadow-xl shadow-black/50'
            : 'bg-[#191919] border-b border-white/10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 sm:h-24 lg:h-[100px] flex items-center justify-between">
          
          {/* Left: Brand Yatra Logo */}
          <a
            href="#"
            className="flex items-center gap-3.5 group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F74300] rounded-lg p-1"
            aria-label="Brand Yatra Home"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-[#222222] border border-[#333333] group-hover:border-[#F74300] transition-colors flex items-center justify-center p-2 shadow-sm">
              <svg
                viewBox="0 0 40 40"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="w-full h-full"
              >
                <path
                  d="M8 32L20 8L32 32H24L20 18L16 32H8Z"
                  fill="#F74300"
                />
                <circle cx="20" cy="27" r="3" fill="#FFE4D6" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="font-['Marcellus',serif] text-xl sm:text-2xl tracking-wider text-[#FFF8F3] uppercase leading-none group-hover:text-[#F74300] transition-colors">
                BRAND YATRA
              </span>
              <span className="text-[9px] uppercase tracking-[0.24em] text-[#B8B8C2] font-semibold mt-1">
                Creative Agency
              </span>
            </div>
          </a>

          {/* Center: Desktop Navigation Links with Marcellus Typography */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="font-['Marcellus',serif] text-sm tracking-widest text-[#B8B8C2] hover:text-[#FFF8F3] transition-colors duration-200 py-2 relative group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F74300] rounded"
              >
                <span>{link.name}</span>
                <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#F74300] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Right: Circular Hamburger Button (64-70px wide, Brand Yatra Orange #F74300) */}
          <div className="flex items-center">
            <button
              ref={hamburgerRef}
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-expanded={isMenuOpen}
              aria-label={isMenuOpen ? 'Close Navigation Menu' : 'Open Full Screen Navigation Menu'}
              className="group relative w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#F74300] hover:bg-[#FF5514] text-white flex items-center justify-center transition-all duration-300 shadow-lg shadow-[#F74300]/30 hover:shadow-xl hover:shadow-[#F74300]/50 hover:scale-105 active:scale-95 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              {isMenuOpen ? (
                <X className="w-7 h-7 stroke-[2.2] animate-in spin-in-90 duration-200" />
              ) : (
                /* Minimalist Four-Square Grid Icon */
                <div className="grid grid-cols-2 gap-1.5 w-6 h-6 items-center justify-center transition-transform duration-300 group-hover:rotate-90 group-hover:scale-105">
                  <span className="w-2.5 h-2.5 bg-white rounded-[2px] shadow-sm transition-transform duration-300 group-hover:-translate-x-0.5 group-hover:-translate-y-0.5" />
                  <span className="w-2.5 h-2.5 bg-white rounded-[2px] shadow-sm transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  <span className="w-2.5 h-2.5 bg-white rounded-[2px] shadow-sm transition-transform duration-300 group-hover:-translate-x-0.5 group-hover:translate-y-0.5" />
                  <span className="w-2.5 h-2.5 bg-white rounded-[2px] shadow-sm transition-transform duration-300 group-hover:translate-x-0.5 group-hover:translate-y-0.5" />
                </div>
              )}
            </button>
          </div>

        </div>
      </header>

      {/* Cinematic Full-Screen Split Overlay Menu */}
      <FullScreenMenu
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        triggerButtonRef={hamburgerRef}
      />
    </>
  );
};
