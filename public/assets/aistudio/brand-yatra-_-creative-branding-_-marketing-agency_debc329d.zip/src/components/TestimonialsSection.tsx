import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Quote, Star } from 'lucide-react';
import { TESTIMONIALS_LIST } from '../data/agencyData';

export const TestimonialsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const current = TESTIMONIALS_LIST[currentIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? TESTIMONIALS_LIST.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === TESTIMONIALS_LIST.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="testimonials" className="bg-[#141414] text-[#FFF8F3] relative overflow-hidden">
      <div className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title with Marcellus */}
        <div className="mb-14">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-2 h-2 rounded-full bg-[#F74300]" />
            <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#FFE4D6]">
              PARTNER VOICES
            </span>
          </div>
          <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl text-[#FFF8F3] tracking-tight uppercase">
            CLIENT <span className="text-[#F74300]">THOUGHTS</span>
          </h2>
        </div>

        {/* Testimonial Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left: Giant Circular Quote Emblem */}
          <div className="lg:col-span-4 flex justify-center">
            <div className="w-52 h-52 sm:w-64 sm:h-64 rounded-full bg-[#191919] border-2 border-[#333333] flex items-center justify-center p-8 relative shadow-2xl group hover:border-[#F74300] transition-colors">
              <div className="absolute inset-2 rounded-full border border-dashed border-[#333333]/60" />
              <Quote className="w-20 h-20 text-[#F74300] stroke-[1.2] fill-[#F74300]/10" />
            </div>
          </div>

          {/* Right: Testimonial Copy & Attribution */}
          <div className="lg:col-span-8 flex flex-col justify-between">
            <div className="mb-8">
              {/* Star Rating */}
              <div className="flex items-center gap-1 mb-4 text-[#F74300]">
                {[...Array(current.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>

              {/* Headline Callout with Marcellus */}
              <h3 className="font-['Marcellus',serif] text-2xl sm:text-3xl text-[#FFF8F3] tracking-tight uppercase mb-4 leading-snug">
                "YOUR TRUSTED DIGITAL PARTNER FOR BUILDING SUCCESS FROM THE GROUND UP"
              </h3>

              {/* Quote Body */}
              <blockquote className="font-['Plus_Jakarta_Sans',sans-serif] text-sm sm:text-base text-[#B8B8C2] leading-relaxed italic mb-6">
                "{current.quote}"
              </blockquote>

              {/* Attribution */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#F74300] text-white font-['Marcellus',serif] flex items-center justify-center text-sm">
                  {current.clientName.charAt(0)}
                </div>
                <div>
                  <div className="font-['Marcellus',serif] text-base sm:text-lg text-[#FFF8F3] uppercase tracking-wide">
                    {current.clientName}
                  </div>
                  <div className="text-xs text-[#B8B8C2] font-['Plus_Jakarta_Sans',sans-serif]">
                    {current.role} · <span className="text-[#F74300] font-medium">{current.company}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Controls & Pagination Dots */}
            <div className="flex items-center justify-between pt-6 border-t border-[#333333]">
              <div className="flex items-center gap-2">
                {TESTIMONIALS_LIST.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentIndex(i)}
                    className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                      currentIndex === i ? 'w-8 bg-[#F74300]' : 'w-2 bg-[#333333]'
                    }`}
                    aria-label={`Go to slide ${i + 1}`}
                  />
                ))}
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handlePrev}
                  className="w-10 h-10 rounded-full bg-[#191919] border border-[#333333] hover:border-[#F74300] text-[#FFF8F3] hover:text-[#F74300] flex items-center justify-center transition-all cursor-pointer active:scale-95"
                  aria-label="Previous testimonial"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNext}
                  className="w-10 h-10 rounded-full bg-[#191919] border border-[#333333] hover:border-[#F74300] text-[#FFF8F3] hover:text-[#F74300] flex items-center justify-center transition-all cursor-pointer active:scale-95"
                  aria-label="Next testimonial"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
