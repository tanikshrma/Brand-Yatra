import React from 'react';
import {
  Compass,
  TrendingUp,
  Search,
  Target,
  Share2,
  Layers,
  Monitor,
  PenTool,
  ArrowUpRight
} from 'lucide-react';
import { SERVICES_LIST, ServiceItem } from '../data/agencyData';
import { BtnShape } from './BtnShape';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
  onOpenConsultation: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onSelectService,
  onOpenConsultation,
}) => {
  const getIcon = (iconName: string) => {
    const props = { className: 'w-5 h-5 text-[#F74300] stroke-[1.8]' };
    switch (iconName) {
      case 'compass':
        return <Compass {...props} />;
      case 'trending-up':
        return <TrendingUp {...props} />;
      case 'search':
        return <Search {...props} />;
      case 'target':
        return <Target {...props} />;
      case 'share-2':
        return <Share2 {...props} />;
      case 'layers':
        return <Layers {...props} />;
      case 'monitor':
        return <Monitor {...props} />;
      case 'pen-tool':
        return <PenTool {...props} />;
      default:
        return <Target {...props} />;
    }
  };

  return (
    <section id="services" className="py-24 bg-[#191919] border-t border-[#333333] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header with Circular Orange Badge */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div>
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-2 h-2 rounded-full bg-[#F74300]" />
              <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#FFE4D6]">
                CORE SERVICES
              </span>
            </div>
            <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl text-[#FFF8F3] tracking-tight uppercase">
              DISCOVER OUR <span className="text-[#F74300]">CAPABILITIES</span>
            </h2>
          </div>

          {/* Reference-matched circular orange badge */}
          <div className="flex items-center gap-4">
            <button
              onClick={onOpenConsultation}
              className="group relative w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-[#F74300] hover:bg-[#FF5514] text-[#191919] transition-all duration-300 flex flex-col items-center justify-center p-2 shadow-xl shadow-[#F74300]/25 hover:scale-105 active:scale-95 cursor-pointer"
            >
              <span className="font-['Marcellus',serif] text-[12px] sm:text-xs tracking-wider uppercase text-white leading-tight text-center">
                LET'S
                <br />
                TALK
              </span>
              <ArrowUpRight className="w-4 h-4 text-white stroke-[2.5] mt-0.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>
        </div>

        {/* 8 Services Grid in 4 Columns x 2 Rows without background or border */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {SERVICES_LIST.map((service) => (
            <div
              key={service.id}
              className="group relative bg-transparent border-none p-6 transition-all duration-300 flex flex-col justify-between overflow-hidden"
            >
              {/* Portrait Shape Overlay from /public/assets/car_shape.webp */}
              <img
                src="/assets/car_shape.webp"
                alt=""
                className="absolute inset-0 w-full h-full object-fill pointer-events-none z-0 opacity-40 group-hover:opacity-85 transition-opacity duration-300"
              />

              <div className="relative z-10">
                {/* Outlined Icon Box */}
                <div className="w-11 h-11 rounded-lg bg-[#191919] border border-[#333333] group-hover:border-[#F74300] flex items-center justify-center mb-5 transition-colors">
                  {getIcon(service.icon)}
                </div>

                {/* Service Title with Marcellus Serif */}
                <h3 className="font-['Marcellus',serif] text-lg sm:text-xl text-[#FFF8F3] mb-2.5 uppercase tracking-wide group-hover:text-[#F74300] transition-colors">
                  {service.title}
                </h3>

                {/* Short Description */}
                <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs text-[#B8B8C2] leading-relaxed line-clamp-3 mb-6">
                  {service.shortDesc}
                </p>
              </div>

              {/* Compact Rectangular Explore Button using BtnShape */}
              <div className="relative z-10 pt-2">
                <button
                  onClick={() => onSelectService(service)}
                  className="group/btn relative w-full flex items-center justify-between text-[#FFF8F3] hover:text-white font-['Plus_Jakarta_Sans',sans-serif] text-[11px] font-bold uppercase tracking-wider py-2.5 px-4 rounded-md transition-all duration-200 cursor-pointer"
                >
                  <BtnShape fill="#191919" className="group-hover/btn:fill-[#F74300] transition-colors" />
                  <span className="relative z-10">EXPLORE SERVICE</span>
                  <ArrowUpRight className="relative z-10 w-3.5 h-3.5 stroke-[2] group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
