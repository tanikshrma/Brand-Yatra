import React from 'react';

export const TickerMarquee: React.FC = () => {
  const items = [
    'BRAND STRATEGY',
    'DIGITAL MARKETING',
    'GOOGLE ADS / PPC',
    'AI & GEO OPTIMIZATION',
    'SOCIAL MEDIA MARKETING',
    'EXPERIENCE DESIGN',
    'WEB DESIGN & DEV',
    'PERFORMANCE MARKETING',
    'COMMERCIAL STORYTELLING',
    'LANDING PAGE & CRO',
    'SEARCH ENGINE OPTIMIZATION',
  ];

  return (
    <div className="bg-[#F74300] text-white py-3.5 overflow-hidden select-none border-y border-[#FF5514]">
      <div className="animate-marquee flex items-center gap-8 whitespace-nowrap">
        {[...items, ...items].map((item, idx) => (
          <div key={idx} className="flex items-center gap-8">
            <span className="font-['Marcellus',serif] text-sm uppercase tracking-[0.2em]">
              {item}
            </span>
            <span className="text-white/60 text-sm">✦</span>
          </div>
        ))}
      </div>
    </div>
  );
};
