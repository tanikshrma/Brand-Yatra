import React from 'react';
import { ArrowUpRight, TrendingUp, Sparkles, ShieldCheck, Check } from 'lucide-react';
import { PORTFOLIO_SHOWCASE, PortfolioItem } from '../data/agencyData';
import { BtnShape } from './BtnShape';

interface PortfolioShowcaseProps {
  onSelectProject: (project: PortfolioItem) => void;
  onOpenConsultation: () => void;
}

export const PortfolioShowcase: React.FC<PortfolioShowcaseProps> = ({
  onSelectProject,
  onOpenConsultation,
}) => {
  return (
    <section id="portfolio" className="py-24 bg-[#191919] text-[#FFF8F3] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Number Badge & Eyebrow */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-7 h-7 rounded-full bg-[#F74300] text-white text-xs font-bold flex items-center justify-center font-mono">
            2
          </div>
          <span className="font-['Marcellus',serif] text-xs uppercase tracking-[0.25em] text-[#FFE4D6]">
            PORTFOLIO
          </span>
        </div>

        {/* Section Heading with Marcellus */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div>
            <h2 className="font-['Marcellus',serif] text-3xl sm:text-4xl md:text-5xl text-[#FFF8F3] uppercase tracking-tight">
              SHOWCASING OUR <span className="text-[#F74300]">EXCELLENCE</span>
            </h2>
            <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm text-[#B8B8C2] mt-2 max-w-xl">
              High-intent customer acquisition, brand transformations, and digital flagship
              experiences delivered for industry leaders.
            </p>
          </div>
        </div>

        {/* Three Large Horizontal Portfolio Cards without background or border */}
        <div className="space-y-8">
          {PORTFOLIO_SHOWCASE.map((project, idx) => (
            <div
              key={project.id}
              className="relative bg-transparent border-none p-6 sm:p-10 lg:p-12 transition-all duration-300 group overflow-hidden"
            >
              {/* Horizontal Card Shape Frame from /public/assets/srv_shape.webp */}
              <img
                src="/assets/srv_shape.webp"
                alt=""
                aria-hidden="true"
                className="absolute inset-0 w-full h-full object-fill pointer-events-none z-0 opacity-30 group-hover:opacity-75 transition-opacity duration-300"
              />

              <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                {/* Left Column: Details & Stats */}
                <div className="lg:col-span-5 flex flex-col justify-between">
                  <div>
                    {/* Client & Service */}
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-[#F74300] font-['Marcellus',serif] text-sm tracking-wider uppercase">
                        {project.client}
                      </span>
                      <span className="text-[#B8B8C2]/60 text-xs">/</span>
                      <span className="text-xs text-[#B8B8C2] uppercase tracking-wider font-['Plus_Jakarta_Sans',sans-serif]">
                        {project.service}
                      </span>
                    </div>

                    {/* Headline with Marcellus */}
                    <h3 className="font-['Marcellus',serif] text-2xl sm:text-3xl text-[#FFF8F3] tracking-tight mb-4 group-hover:text-[#F74300] transition-colors">
                      {project.headline}
                    </h3>

                    {/* Description */}
                    <p className="font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm text-[#B8B8C2] leading-relaxed mb-6 font-normal">
                      {project.description}
                    </p>

                    {/* Metric Badges */}
                    <div className="grid grid-cols-3 gap-3 pt-4 border-t border-[#333333] mb-8">
                      {project.metrics.map((m, mIdx) => (
                        <div key={mIdx}>
                          <div className="font-['Marcellus',serif] text-xl sm:text-2xl text-[#FFF8F3]">
                            {m.value}
                          </div>
                          <div className="text-[10px] text-[#B8B8C2] uppercase tracking-wider font-medium font-['Plus_Jakarta_Sans',sans-serif]">
                            {m.label}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* CTA Buttons */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onSelectProject(project)}
                      className="group/btn relative inline-flex items-center justify-center gap-2 text-white font-['Plus_Jakarta_Sans',sans-serif] text-xs font-bold uppercase tracking-wider px-6 py-3 transition-all duration-200 active:scale-95 cursor-pointer filter drop-shadow-[0_4px_12px_rgba(247,67,0,0.25)]"
                    >
                      <BtnShape fill="#F74300" />
                      <span className="relative z-10">VIEW CASE STUDY</span>
                      <ArrowUpRight className="relative z-10 w-3.5 h-3.5 stroke-[2]" />
                    </button>
                    <button
                      onClick={onOpenConsultation}
                      className="text-xs font-semibold text-[#B8B8C2] hover:text-[#F74300] uppercase tracking-wider px-3 py-2 cursor-pointer font-['Plus_Jakarta_Sans',sans-serif]"
                    >
                      Get Similar Results
                    </button>
                  </div>
                </div>

                {/* Right Column: Visual Showcase Preview Mockup */}
                <div className="lg:col-span-7">
                  <div className="relative rounded-2xl overflow-hidden border border-[#35363D] bg-[#111216] p-4 sm:p-6 shadow-inner">
                    {/* Mockup top browser/app bar */}
                    <div className="flex items-center justify-between pb-4 mb-4 border-b border-[#35363D]/60 text-xs text-[#A7A7AD]">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                        <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                        <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                        <span className="ml-2 font-mono text-[10px] text-[#A7A7AD]/80">
                          brandyatra.com/work/{project.id}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono uppercase bg-[#191A1F] px-2 py-0.5 rounded border border-[#35363D]">
                        VERIFIED AUDIT
                      </span>
                    </div>

                    {/* Rich Pinterest-style stock image showcase previews with stats overlays */}
                    {project.visualType === 'banking' && (
                      <div className="relative rounded-xl overflow-hidden border border-[#35363D] group/img h-64 sm:h-72">
                        <img
                          src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?q=80&w=1200&auto=format&fit=crop"
                          alt="HSBC Financial Tech Showcase"
                          className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-[#111216] via-[#111216]/60 to-transparent p-5 flex flex-col justify-between">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] uppercase tracking-widest text-[#F74300] font-bold bg-[#191919]/90 px-3 py-1 rounded-full border border-[#35363D]">
                              HSBC WEALTH PORTFOLIO
                            </span>
                            <span className="text-[10px] bg-[#F74300] text-white px-2.5 py-1 rounded-full font-bold">
                              ROAS: 7.8x
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-bold text-white mb-2">
                              Multi-Market Lead Optimization
                            </div>
                            <div className="grid grid-cols-3 gap-2">
                              <div className="bg-[#191919]/80 backdrop-blur-sm p-2 rounded border border-[#35363D] text-center">
                                <div className="text-[9px] text-[#A7A7AD]">Leads</div>
                                <div className="text-xs font-bold text-white">4,890</div>
                              </div>
                              <div className="bg-[#191919]/80 backdrop-blur-sm p-2 rounded border border-[#35363D] text-center">
                                <div className="text-[9px] text-[#A7A7AD]">CPA</div>
                                <div className="text-xs font-bold text-white">$14.20</div>
                              </div>
                              <div className="bg-[#191919]/80 backdrop-blur-sm p-2 rounded border border-[#35363D] text-center">
                                <div className="text-[9px] text-[#A7A7AD]">Intent</div>
                                <div className="text-xs font-bold text-[#F74300]">98.4%</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {project.visualType === 'tech' && (
                      <div className="relative rounded-xl overflow-hidden border border-[#35363D] group/img h-64 sm:h-72">
                        <img
                          src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop"
                          alt="OnePlus Tech Flagship Experience"
                          className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-[#111216] via-[#111216]/60 to-transparent p-5 flex flex-col justify-between">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] uppercase tracking-widest text-[#F74300] font-bold bg-[#191919]/90 px-3 py-1 rounded-full border border-[#35363D]">
                              ONEPLUS FLAGSHIP
                            </span>
                            <span className="text-[10px] bg-[#191919]/90 text-[#FFE4D6] border border-[#F74300]/40 px-2.5 py-1 rounded-full font-bold">
                              120K+ Units Sold
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-['Marcellus',serif] text-white mb-2">
                              "The Speed You Need"
                            </div>
                            <div className="flex gap-2">
                              <span className="text-[10px] bg-[#F74300] text-white px-2.5 py-1 rounded-full font-bold">
                                18.4M Impressions
                              </span>
                              <span className="text-[10px] bg-[#191919]/80 backdrop-blur-sm text-white px-2.5 py-1 rounded-full border border-[#35363D]">
                                120 FPS Fluid
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {project.visualType === 'luxury' && (
                      <div className="relative rounded-xl overflow-hidden border border-[#35363D] group/img h-64 sm:h-72">
                        <img
                          src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?q=80&w=1200&auto=format&fit=crop"
                          alt="Sobha Limited Luxury Architecture"
                          className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-[#111216] via-[#111216]/60 to-transparent p-5 flex flex-col justify-between">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] uppercase tracking-widest text-[#F74300] font-bold bg-[#191919]/90 px-3 py-1 rounded-full border border-[#35363D]">
                              SOBHA LUXURY VILLAS
                            </span>
                            <span className="text-[10px] bg-[#F74300] text-white px-2.5 py-1 rounded-full font-bold">
                              94% Sold
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-['Marcellus',serif] text-white mb-2">
                              "Exclusivity Beckons"
                            </div>
                            <div className="flex gap-2">
                              <span className="text-[10px] bg-[#F74300] text-white px-2.5 py-1 rounded-full font-bold">
                                2,100+ Qualified Tours
                              </span>
                              <span className="text-[10px] bg-[#191919]/80 backdrop-blur-sm text-white px-2.5 py-1 rounded-full border border-[#35363D]">
                                VIP Desk
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Projects Button */}
        <div className="mt-14 text-center">
          <button
            onClick={onOpenConsultation}
            className="group relative inline-flex items-center justify-center gap-2.5 text-white font-['Plus_Jakarta_Sans',sans-serif] text-xs sm:text-sm font-bold uppercase tracking-wider px-8 py-4 transition-all duration-200 filter drop-shadow-[0_8px_20px_rgba(247,67,0,0.3)] hover:scale-105 active:scale-95 cursor-pointer"
          >
            <BtnShape fill="#F74300" />
            <span className="relative z-10">VIEW ALL PROJECTS &amp; CASE STUDIES</span>
            <ArrowUpRight className="relative z-10 w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </section>
  );
};
